<?php

    phpinfo();


?>
