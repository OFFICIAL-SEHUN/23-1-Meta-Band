<!DOCTYPE HTML>
<!--
	TXT by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	
	<head>
		<title>Meta-Band</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
        <link rel="stylesheet" href="css.css">
	</head>
	<body class="homepage is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header">
					<div class="logo container">
						<div>
							<h1><a href="index.html" id="logo"></a></h1>
							<p></p>
						</div>
					</div>
				</header>

			<!-- Nav -->
				<nav id="nav">
					<ul>
						<li><a href="/login_status/index.html">Home</a></li>
						<li><a href="/login_status/unity/unity.html">모니터링 메뉴</a></li>
						<li><a href="/logout_status/login_register/login_view.php">로그아웃</a></li>
						<li class="current"><a href="/login_status/freeboard/freeboard_list.php">자유 게시판</a></li>
						<li><a href="/login_status/service_center/service.html">고객센터</a></li>
					</ul>
				</nav>




                <div class="board_wrap">
                    <div class="board_title">
                        <strong>자유 게시판</strong>
                        <p>여러가지 정보들을 공유하는 게시판입니다.<br>
                        자유롭게 글을 작성하고 댓글을 남기세요.
                        </p>
            
                    </div>
                    <div class="board_list_wrap">
                        
					<?php
						include ("lib.php");
					?>
						<table width=800 border="1">
							<tr>
								<th width = 50> No </th>
								<th> 제목 </th>
								<th width = 150> 작성자 </th>
								<th width = 150> 작성시간 </th>
							</tr>
						<?php

							$sql = "SELECT * FROM freeboard ORDER BY idx DESC";
							$result = mysqli_query($con,$sql);
							while($data = mysqli_fetch_array($result)){
						?>
							<tr>
								<th> <?=$data['idx']?> </th>
								<th> <a href="/login_status/freeboard/write/view.php?idx=<?=$data['idx']?>"><?=$data['subject']?></a> </th>
								<th> <?=$data['name']?> </th>
								<th> <?=substr($data['regdate'],0,10)?> </th>
							</tr>	
						<?php } ?>
						
						</table>
                        <div class="board_page">
                            <a href="" class="bt first"><<<</a>
                            <a href="" class="bt prev"><</a>
                            <a href="" class="num on">1</a>
                            <a href="" class="num">2</a>
                            <a href="" class="num">3</a>
                            <a href="" class="num">4</a>
                            <a href="" class="num">5</a>
                            <a href="" class="bt next">></a>
                            <a href="" class="bt last">>>></a>
            
                        </div>

						
                    </div>
					
					

                </div>

				<div class="bt_wrap">
							<a href="/login_status/freeboard/write/write.php" class="on">글쓰기</a>
				</div>
		
			
		</div>
		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
	
</html>
