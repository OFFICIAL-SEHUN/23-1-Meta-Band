<!--view.php 에서 삭제를 클릭했을 경우 게시글을 삭제하는 파일-->
<?php
    include ("lib.php");
 
    $idx = $_GET['idx'];
    $pwd = $_POST['password'];
    
    $idx = mysqli_real_escape_string($con, $idx);
    $pwd = mysqli_real_escape_string($con, $pwd);

    $sql_pwd = "SELECT * FROM freeboard WHERE idx='$idx'";
    $result = mysqli_query($con, $sql_pwd);
    $sql_pwd = mysqli_fetch_array($result);

    function redirectBack($message) {
        echo '<script>alert("' . $message . '");</script>';
        echo '<script>window.history.back();</script>';
        exit;
    }


//삭제하려는 게시물번호에 대하여
    if(isset($pwd)){ //비밀번호가 edit.php에서 넘어왔다면
        //검증 실시
        if($pwd === $sql_pwd['pwd']){
            $sql = "delete from freeboard where idx='$idx' ";
            mysqli_query($con, $sql);
        }
        else{
            redirectBack('틀린 비밀번호 입니다.');
        }
    } 
    else{ //비밀번호가 edit.php에서 넘어오지않았다면
        redirectBack('틀린 비밀번호 입니다.');
    }

    mysqli_query($con,$sql);
    
    //저장 후 페이지 이동 구현
    header("location: /login_status/freeboard/freeboard_list.php");
?>
