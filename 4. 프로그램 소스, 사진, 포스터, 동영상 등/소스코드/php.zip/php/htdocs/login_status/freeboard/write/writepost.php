<!--write.php 에서 획득한 값을 writepost.php로 database에 전달해주는 파일-->
<?php
    include ("lib.php");
 
    $idx = $_POST['idx'];
    $name = $_POST['name'];
    $subject = $_POST['subject'];
    $memo = $_POST['memo'];
    $pwd = $_POST['pwd'];

    $idx = mysqli_real_escape_string($con, $idx); 
    $name = mysqli_real_escape_string($con, $name); 
    $subject = mysqli_real_escape_string($con, $subject); 
    $memo = mysqli_real_escape_string($con, $memo); 
    $pwd = mysqli_real_escape_string($con, $pwd);

    
    $regdate = date("Y-m-d H:i:s"); 
    $ip = $_SERVER['REMOTE_ADDR']; 

    $sql = "insert into freeboard(name, subject, memo, regdate, ip, pwd)
        values('$name','$subject','$memo','$regdate','$ip','$pwd') ";


    mysqli_query($con, $sql); 
    

    //저장 후 페이지 이동 구현
    header("location: /login_status/freeboard/freeboard_list.php");
?>
<?php
	mysqli_close($con);
?>
