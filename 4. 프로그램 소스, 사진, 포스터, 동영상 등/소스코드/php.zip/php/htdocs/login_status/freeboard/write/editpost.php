<!--edit.php 에서 획득한 값을 editpost.php로 database에 전달해주는 파일-->
<?php
    include ("lib.php");
 
    $idx = $_POST['idx'];
    $name = $_POST['name'];
    $subject = $_POST['subject'];
    $memo = $_POST['memo'];
    $pwd = $_POST['pwd'];

    $idx = mysqli_real_escape_string($con, $idx); 
    $name = mysqli_real_escape_string($con, $name); 
    $subject = mysqli_real_escape_string($con, $subject); 
    $memo = mysqli_real_escape_string($con, $memo); 
    $pwd = mysqli_real_escape_string($con, $pwd);

    $sql_pwd = "SELECT * FROM freeboard WHERE idx='$idx'";
    $result = mysqli_query($con, $sql_pwd);
    $sql_pwd = mysqli_fetch_array($result);

    $regdate = date("Y-m-d H:i:s"); 
    $ip = $_SERVER['REMOTE_ADDR']; 

    if(isset($_POST['pwd'])){ //비밀번호가 edit.php에서 넘어왔다면
        //검증 실시
        if($pwd === $sql_pwd['pwd']){
            $sql = "UPDATE freeboard SET name='$name', subject='$subject', memo='$memo' WHERE idx='$idx' "; 
            mysqli_query($con, $sql);
        }
        else{
            echo "
            <script>
            alert('비밀번호가 달라 수정이 불가능합니다.');
            history.back(1); 
            </script>            
            ";
            exit; 
        }
    } 
    else{ //비밀번호가 edit.php에서 넘어오지않았다면
    }
    //저장 후 페이지 이동 구현
    header("location: /login_status/freeboard/freeboard_list.php");
?>

