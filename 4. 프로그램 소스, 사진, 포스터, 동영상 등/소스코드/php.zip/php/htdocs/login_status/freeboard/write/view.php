<!DOCTYPE HTML>
<!--
   TXT by HTML5 UP
   html5up.net | @ajlkn
   Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
   <head>
      <title>Meta-Band</title>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
      <link rel="stylesheet" href="assets/css/main.css" />
        <link rel="stylesheet" href="css.css">
   </head>
   <body class="homepage is-preload">
      <div id="page-wrapper">

         <!-- Header -->
            <header id="header">
               <div class="logo container">
                  <div>
                     <h1><a href="index.html" id="logo"></a></h1>
                     <p></p>
                  </div>
               </div>
            </header>

         <!-- Nav -->
            <nav id="nav">
               <ul>
               <li><a href="/login_status/index.html">Home</a></li>
						<li><a href="/login_status/unity/unity.html">모니터링 메뉴</a></li>
						<li><a href="/logout_status/login_register/login_view.php">로그아웃</a></li>
						<li class="current"><a href="/login_status/freeboard/freeboard_list.php">자유 게시판</a></li>
						<li><a href="/login_status/service_center/service.html">고객센터</a></li>
               </ul>
            </nav>

               <div class="board_wrap">
                  <div class="board_title">
                     <strong>자유 게시판</strong>
                     <p>여러가지 정보들을 공유하는 게시판입니다.<br>
                     자유롭게 글을 작성하고 댓글을 남기세요.
                     </p>
                  </div>
            

                  <div class="board_view_wrap">
                     <?php
                        include ("lib.php");

                        $idx = $_GET['idx'];
                        $idx = mysqli_real_escape_string($con, $idx);

                        $sql = "select * from freeboard where idx='$idx' ";
                        $result = mysqli_query($con,$sql);
                        $data = mysqli_fetch_array($result);
                     ?>

                     <form id="deleteForm" action="del_post.php" method="post">
                        <input type="hidden" id="password" name="password">
                        <div class="board_view">
                           <div class="title">
                              <td style="font-size: 40px; text-align: left;"><?php echo $data['subject'] ?></td>
                           </div>
                           <div class = "info">
                              <dl>
                                 <dt> 번호 </dt>
                                 <dd style="font-size: 20px; text-align: left;"><?php echo $data['idx'] ?></dd>
                              </dl>

                              <dl>
                                 <dt> 작성자 </dt>
                                 <dd style="font-size: 20px; text-align: left;"><?php echo $data['name'] ?> </dd>
                              </dl>

                              <dl>
                                 <dt> 작성 일자 </dt>
                                 <dd style="font-size: 20px; text-align: left;"> <?php echo substr($data['regdate'],0,10) ?> </dd>
                              </dl>

                              
                           </div>

                           <div class = "cont">   
                              <dl> 
                                 <dd style="font-size: 25px;"> <?php echo nl2br($data['memo'])?> </dd>
                              </dl>
                           </div> 
                        </div>
                        <div class="bt_wrap">
                           <tr>
                              <td colspan="2">
                                 <div style="float:right; ">
                                    <a href="#" onclick="showAlert(event,'<?php echo $idx; ?>')">삭제</a>
                                    <a href="/login_status/freeboard/write/edit.php?idx=<?=$idx?>">수정</a>
                                 </div>


                                 <a href="/login_status/freeboard/freeboard_list.php">목록</a>
                              </td>
                           </tr>
                        </div>

                        <script>
                           function showAlert(event,idx) {
                              event.preventDefault(); // 기본 동작 막기
                              var password = prompt('비밀번호를 입력하세요:');
                                    if (password) {
                                       document.getElementById('password').value = password;
                                       document.getElementById('deleteForm').action = '/login_status/freeboard/write/del_post.php?idx=<?=$idx?>';
                                       document.getElementById('deleteForm').submit();
                                    }
                           }
                        </script>
                     </form>
                  </div>
               </div>
         

      <!-- Scripts -->
         <script src="assets/js/jquery.min.js"></script>
         <script src="assets/js/jquery.dropotron.min.js"></script>
         <script src="assets/js/jquery.scrolly.min.js"></script>
         <script src="assets/js/browser.min.js"></script>
         <script src="assets/js/breakpoints.min.js"></script>
         <script src="assets/js/util.js"></script>
         <script src="assets/js/main.js"></script>

   </body>
</html>