<!DOCTYPE HTML>
<!--
	TXT by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Meta_Band</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
        <link rel="stylesheet" href="css.css">
	</head>
	<body class="homepage is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header">
					<div class="logo container">
						<div>
							<h1><a href="index.html" id="logo"></a></h1>
							<p></p>
						</div>
					</div>
				</header>

			<!-- Nav -->
				<nav id="nav">
					<ul>
					<li><a href="/login_status/index.html">Home</a></li>
						<li><a href="/login_status/unity/unity.html" >모니터링 메뉴</a></li>
						<li><a href="/logout_status/login_register/login_view.php">로그아웃</a></li>
						<li class="current"><a href="/login_status/freeboard/freeboard_list.php" >자유 게시판</a></li>
						<li><a href="/login_status/service_center/service.html" >고객센터</a></li>
					</ul>
				</nav>

				<?php
					include "lib.php";

					$idx = $_GET['idx'];
					$sql = "SELECT * FROM freeboard WHERE idx='$idx' ";
					$result = mysqli_query($con,$sql);
					$data = mysqli_fetch_array($result);

				?>

                <div class="board_wrap">
                    <div class="board_title">
                        <strong>자유 게시판</strong>
                        <p>여러가지 정보들을 공유하는 게시판입니다.<br>
                        자유롭게 글을 작성하고 댓글을 남기세요.
                        </p>
            
                    </div>
                    <div class="board_list_wrap">
						<form action="editpost.php" method="post">
							<input type="hidden" name="idx" value="<?php echo $idx?>">
							<table width=800 border="1" cellpadding=5 >
								<tr>
									<th> 이름 </th>
									<td> <input type="text" name ="name" value = "<?=$data['name']?>"></td>
								</tr>

								<tr> 
									<th> 제목 </th> 
									<td> <input type="text" name ="subject" value = "<?=$data['subject']?>"></td>
								</tr>

								<tr>
									<th> 내용 </th> 
									<td> 
										<textarea name="memo"><?= $data['memo']?></textarea> 
									</td>
								</tr>

								<tr>
									<th> 비밀번호 </th> 
									<td> <input type="password" name="pwd" placeholder="비밀번호"  size=20 > </td>
								</tr>

								<tr>
									<td colspan="2">
										<div style="text-align:center; ">
											<input type="submit" value="저장">
										</div>
									</td>
								</tr>
								
							</table>
						</form>
                    </div>
                </div>
		
			

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>