<?php
    $con = mysqli_connect("localhost","root","1q2w3e4r","level1") or die("MySQL 접속 실패");
    
    //echo "MySQL 접속 완전히 성공!!";
    
    //mysqli_close($con);
?>
