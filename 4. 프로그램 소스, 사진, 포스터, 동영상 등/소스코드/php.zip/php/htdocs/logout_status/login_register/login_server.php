<?php

include ("db.php");

if(isset($_POST['user_id']) && isset($_POST['password1'])){
    //빈칸이 없다면 회원가입 진행  
    
    //보안을 더욱 강화 (보안코딩)
    $user_id = mysqli_real_escape_string($con,$_POST['user_id']);
    $password1 = mysqli_real_escape_string($con,$_POST['password1']);

    //에러체크
    if(empty($user_id)){
        header("location: /login_view.php?error=아이디가 비어있습니다.");
        exit();
    }
    else if(empty($password1)){
        header("location: /login_view.php?error=비밀번호가 비어있습니다.");
        exit();
    }
    else{
        //로그인 구현

        $sql = "select * from member where mb_id = '$user_id'";
        $result = mysqli_query($con,$sql);

        if(mysqli_num_rows($result) === 1){
            //로그인
            $row = mysqli_fetch_assoc($result);

            $hash = $row['password'];
            if(password_verify($password1,$hash)){
                header("location: /login_status/index.html");
                exit();
            }
            else{
                header("location: login_view.php?error=로그인에 실패하였습니다.");
                exit();
            }
        }
        else{
            header("location: login_view.php?error=없는 아이디 입니다.");
            exit();
        }
    }
}
else{
    header("location: login_view.php?error=알 수 없는 오류 발생.");
    exit();
}
mysqli_close($con);
?>