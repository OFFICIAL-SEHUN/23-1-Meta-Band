<?php

include ("db.php");

if(isset($_POST['user_id']) && isset($_POST['user_nick']) && isset($_POST['password1']) && isset($_POST['password2'])){
    //빈칸이 없다면 회원가입 진행  
    
    //보안을 더욱 강화 (보안코딩)
    $user_id = mysqli_real_escape_string($con,$_POST['user_id']);
    $user_nick = mysqli_real_escape_string($con,$_POST['user_nick']);
    $password1 = mysqli_real_escape_string($con,$_POST['password1']);
    $password2 = mysqli_real_escape_string($con,$_POST['password2']);

    //에러체크
    if(empty($user_id)){
        header("location: register_view.php?error=아이디가 비어있습니다.");
        exit();
    }
    else if(empty($user_nick)){
        header("location: register_view.php?error=닉네임이 비어있습니다.");
        exit();
    }
    else if(empty($password1)){
        header("location: register_view.php?error=비밀번호가 비어있습니다.");
        exit();
    }
    else if(empty($password2)){
        header("location: register_view.php?error=비밀번호 확인란이 비어있습니다.");
        exit();
    }
    else if($password1 !== $password2){
        header("location: register_view.php?error=비밀번호가 일치하지 않습니다.");
        exit();
    }

    else{
        //저장

        //암호화
        $password1 = password_hash($password1,PASSWORD_DEFAULT);

        //아이디,닉네임 중복체크
        $sql_same = "SELECT * FROM member WHERE mb_id='$user_id' or mb_nick='$user_nick'";
        $order = mysqli_query($con, $sql_same);

        if(mysqli_num_rows($order) > 0){
            header("location: register_view.php?error=아이디 또는 닉네임이 이미 있습니다.");
            exit();
        }   
        else{
            //중복이 아니라면 삽입 실행
            $sql_save = "insert into member(mb_id,mb_nick,password) values('$user_id','$user_nick','$password1')";
            $result = mysqli_query($con,$sql_save);
            if($result){
                header("location: register_view.php?success=성공적으로 가입 되었습니다.");
                exit();
            }
            else{
                header("location: register_view.php?error=가입에 실패 하였습니다.");
                exit();
            }
        }
    }
}
else{
    header("location: register_view.php?error=알 수 없는 오류 발생.");
    exit();
}
mysqli_close($con);
?>