const firebase = require("firebase");

const firebaseConfig = {
  apiKey: "AIzaSyCJ22KY1qGSKKKi5pJBnjpY0FbUUQEQKY0",
  authDomain: "metabandtest1.firebaseapp.com",
  databaseURL: "https://metabandtest1-default-rtdb.firebaseio.com",
  projectId: "metabandtest1",
  storageBucket: "metabandtest1.appspot.com",
  messagingSenderId: "392195476588",
  appId: "1:392195476588:web:a75affe344d66c50331c49",
  measurementId: "G-XF4GLMJEQW"
};
firebase.initializeApp(firebaseConfig)
let database = firebase.database();

module.exports = database;