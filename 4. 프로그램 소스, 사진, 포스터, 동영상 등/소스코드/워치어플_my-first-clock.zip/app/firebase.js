// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCJ22KY1qGSKKKi5pJBnjpY0FbUUQEQKY0",
  authDomain: "metabandtest1.firebaseapp.com",
  databaseURL: "https://metabandtest1-default-rtdb.firebaseio.com",
  projectId: "metabandtest1",
  storageBucket: "metabandtest1.appspot.com",
  messagingSenderId: "392195476588",
  appId: "1:392195476588:web:a75affe344d66c50331c49",
  measurementId: "G-XF4GLMJEQW"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

firebase.database().ref("/metabandtest1/").update({key:"data"});

